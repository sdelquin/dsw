from django.urls import path

from . import views

app_name = 'places'

urlpatterns = [
    path('', views.place_list, name='list'),
    path('cat/<slug:cat_slug>/', views.place_list, name='list_by_cat'),
    path('add/', views.add_place, name='add'),
    path('detail/<slug:place_slug>/', views.place_detail, name='detail'),
]
