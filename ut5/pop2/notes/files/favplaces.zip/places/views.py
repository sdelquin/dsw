from categories.models import Category
from django.shortcuts import get_object_or_404, render

from .models import Place


def place_list(request, cat_slug=None):
    places = Place.objects.all()
    if cat_slug:
        category = get_object_or_404(Category, slug=cat_slug)
        places = places.filter(category=category)
    else:
        category = None
    return render(request, 'places/list.html', dict(places=places, category=category))


def add_place(request):
    """Gestionar la petición GET y la petición POST de un formulario
    de modelo. En la petición POST hay que tener en cuenta que se
    suben ficheros y también hay que controlar si el fomulario es válido.
    Ojo porque se debe usar: from django.utils.text import slugify
    para crear el slug del place antes de guardarlo definitivamente."""

    # TODO
    pass


def place_detail(request, place_slug):
    place = get_object_or_404(Place, slug=place_slug)
    return render(request, 'places/detail.html', dict(place=place))
