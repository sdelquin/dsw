from django.db import models


class Place(models.Model):
    name = models.CharField(max_length=128, unique=True)
    slug = models.SlugField(max_length=128, unique=True)
    city = models.CharField(max_length=128)
    lat = models.FloatField(verbose_name='Latitude')
    lon = models.FloatField(verbose_name='Longitude')
    description = models.TextField(blank=True)
    url = models.URLField(blank=True, null=True)
    image = models.ImageField(upload_to='places', blank=True, null=True)
    category = models.ForeignKey(
        'categories.Category', blank=True, null=True, on_delete=models.SET_NULL
    )

    def __str__(self):
        # TODO
        pass

    def google_maps(self):
        # TODO
        pass

    def get_absolute_url(self):
        # TODO
        pass

    class Meta:
        ordering = []  # TODO
