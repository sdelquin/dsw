from django.forms import ModelForm


class AddPlaceForm(ModelForm):
    # TODO
    pass
