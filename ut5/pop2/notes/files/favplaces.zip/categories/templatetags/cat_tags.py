from django import template

from categories.models import Category

register = template.Library()


@register.inclusion_tag('categories/badge.html')
def category_badge(category: Category):
    return dict(category=category)
