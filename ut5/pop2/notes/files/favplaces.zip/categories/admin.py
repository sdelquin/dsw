from django.contrib import admin

from .models import Category


@admin.register(Category)
class PlaceAdmin(admin.ModelAdmin):
    list_display = ('name', 'slug', 'bi_class', 'b_color')
    prepopulated_fields = {'slug': ('name',)}
