from django.db import models


class Category(models.Model):
    name = models.CharField(max_length=128, unique=True)
    slug = models.SlugField(max_length=128, unique=True)
    bi_class = models.CharField(
        max_length=128, help_text='Class for Boostrap icon', default='bi bi-shop-window'
    )
    b_color = models.CharField(
        max_length=128, help_text='Color for badge in Bootstrap', default='primary'
    )
    description = models.TextField(blank=True)

    class Meta:
        verbose_name_plural = 'Categories'

    def __str__(self):
        return self.name
