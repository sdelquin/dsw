from django.conf import settings

urlpatterns = []  # TODO

if settings.DEBUG:
    # TODO
    pass
