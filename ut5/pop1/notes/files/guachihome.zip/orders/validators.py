def validate_phone(value):
    """Se considera un teléfono válido cualquiera que tenga 9 dígitos numéricos"""
    pass
