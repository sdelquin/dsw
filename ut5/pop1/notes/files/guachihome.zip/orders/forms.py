from django.forms import ModelForm

from .models import Order


class SubmitOrderForm(ModelForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self._meta.fields:
            self.fields[field].required = True

    class Meta:
        model = Order
        fields = ('contact', 'phone', 'address')
        labels = {
            'contact': 'Persona de contacto',
            'phone': 'Teléfono de contacto',
            'address': 'Dirección de entrega',
        }
