from django.shortcuts import render

from orders.models import Order


def valid_order_required(func):
    def wrapper(request, order_code, *args, **kwargs):
        try:
            Order.objects.get(code=order_code)
        except Order.DoesNotExist:
            return render(request, 'orders/order_not_found.html', dict(order_code=order_code))

        return func(request, order_code, *args, **kwargs)

    return wrapper
