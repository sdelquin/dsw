from django.urls import path

from . import views

app_name = 'orders'

urlpatterns = [
    path('new_order/', views.new_order, name='new_order'),
    path('retrieve_order/<str:order_code>/', views.retrieve_order, name='retrieve_order'),
    path('clean_order/<str:order_code>/', views.clean_order, name='clean_order'),
    path('cancel_order/<str:order_code>/', views.cancel_order, name='cancel_order'),
    path('order/<str:order_code>/', views.order, name='order'),
    path(
        'order/<str:order_code>/add/<int:product_id>/',
        views.add_product_to_order,
        name='add_product_to_order',
    ),
    path(
        'order/<str:order_code>/del/<int:product_id>/',
        views.delete_product_from_order,
        name='delete_product_from_order',
    ),
    path('order/<str:order_code>/submit/', views.submit_order, name='submit_order'),
    path('order/<str:order_code>/pdf/', views.pdf_order, name='pdf_order'),
]
