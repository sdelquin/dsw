from django.db.models.signals import pre_delete, pre_save
from django.dispatch import receiver

from .models import OrderLine


@receiver(pre_save, sender=OrderLine)
def update_order_price_on_add(instance, **kwargs):
    """Actualiza el precio total del pedido teniendo en cuenta que
    instance es el objeto de tipo OrderLine que va a guardarse"""
    try:
        existing_order_line_price = OrderLine.objects.get(pk=instance.id).price
    except OrderLine.DoesNotExist:
        existing_order_line_price = 0

    instance.order.price -= existing_order_line_price
    instance.order.price += instance.price
    instance.order.save()


@receiver(pre_delete, sender=OrderLine)
def update_order_price_on_delete(instance, **kwargs):
    """Actualiza el precio total del pedido teniendo en cuenta que
    instance es el objeto de tipo OrderLine que va a borrarse"""
    pass
