import random
import string

from django.db import models
from django.urls import reverse

from products.models import Product

from .validators import validate_phone

ORDER_CODE_SIZE = 4


def gen_code():
    def new_code():
        return ''.join(random.choice(string.ascii_uppercase) for _ in range(ORDER_CODE_SIZE))

    existing_codes = Order.objects.all().values_list('code', flat=True)
    while (code := new_code()) in existing_codes:
        pass
    return code


class Order(models.Model):
    code = models.CharField(default=gen_code, max_length=ORDER_CODE_SIZE, unique=True)
    initiated_at = models.DateTimeField(auto_now_add=True)
    submitted_at = models.DateTimeField(blank=True, null=True)
    price = models.DecimalField(max_digits=5, decimal_places=2, blank=True, null=True, default=0)
    contact = models.CharField(max_length=128, blank=True)
    phone = models.CharField(max_length=16, blank=True, validators=[validate_phone])
    address = models.CharField(max_length=512, blank=True)
    products = models.ManyToManyField(Product, related_name='ordered_in', through='OrderLine')

    def get_absolute_url(self):
        return reverse('orders:order', args=[self])

    def __str__(self):
        return self.code

    @property
    def is_submitted(self):
        return self.submitted_at is not None


class OrderLine(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name='order_lines')
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='order_lines')
    quantity = models.PositiveSmallIntegerField(default=1)

    @property
    def price(self):
        return self.product.price * self.quantity

    def __str__(self):
        return f'Order {self.order.code}: {self.quantity}x Product ID={self.product.id}'
