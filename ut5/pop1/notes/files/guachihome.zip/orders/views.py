from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from products.models import Product
from shared.utils import generate_pdf

from .decorators import valid_order_required
from .forms import SubmitOrderForm
from .models import Order, OrderLine


def new_order(request):
    return redirect(Order.objects.create())


def order(request, order_code):
    order = get_object_or_404(Order, code=order_code)
    products = Product.objects.all()
    return render(request, 'orders/order.html', dict(order=order, products=products))


def add_product_to_order(request, order_code, product_id):
    pass


def delete_product_from_order(request, order_code, product_id):
    order = get_object_or_404(Order, code=order_code)
    product = get_object_or_404(Product, pk=product_id)
    order_line = get_object_or_404(OrderLine, order=order, product=product)
    order_line.delete()
    return redirect(order)


def submit_order(request, order_code):
    order = get_object_or_404(Order, code=order_code)
    if request.method == 'GET':
        if order.is_submitted:
            return redirect(order)
        form = SubmitOrderForm()
    else:
        form = SubmitOrderForm(instance=order, data=request.POST)
        if form.is_valid():
            order = form.save(commit=False)
            order.submitted_at = timezone.now()
            order.save()
            return render(request, 'orders/submit_order_result.html', dict(order=order))
    return render(request, 'orders/submit_order.html', dict(order=order, form=form))


@valid_order_required
def retrieve_order(request, order_code):
    order = Order.objects.get(code=order_code)
    return redirect(order)


def clean_order(request, order_code):
    order = get_object_or_404(Order, code=order_code)
    order.products.clear()
    return redirect(order)


def cancel_order(request, order_code):
    order = get_object_or_404(Order, code=order_code)
    order.delete()
    return redirect('dashboard:home')


def pdf_order(request, order_code):
    order = get_object_or_404(Order, code=order_code)
    response = generate_pdf(request, 'orders/pdf.html', f'Pedido_{order.code}', order=order)
    return response
