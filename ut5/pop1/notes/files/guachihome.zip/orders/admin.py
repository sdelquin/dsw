from django.contrib import admin

from .models import Order, OrderLine


class OrderLineInlineAdmin(admin.TabularInline):
    model = OrderLine


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ('code', 'initiated_at', 'price', 'contact', 'phone', 'address')
    inlines = [OrderLineInlineAdmin]
