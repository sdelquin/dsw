document.addEventListener("DOMContentLoaded", (event) => {
  document
    .querySelector("a#retrieve-order-btn")
    .addEventListener("click", retrieveOrder);
  document
    .querySelector("input#order-code")
    .addEventListener("keyup", manageStatusRetrieveOrderButton);
});

function retrieveOrder(event) {
  const orderCode = document
    .querySelector("input#order-code")
    .value.trim()
    .toUpperCase();
  const url = `/orders/retrieve_order/${orderCode}/`;
  window.location = url;
}

function manageStatusRetrieveOrderButton(event) {
  if (event.key === "Enter") {
    retrieveOrder(event);
  }
  let button = document.querySelector("a#retrieve-order-btn");
  if (this.value) {
    button.classList.remove("disabled");
  } else {
    button.classList.add("disabled");
  }
}
