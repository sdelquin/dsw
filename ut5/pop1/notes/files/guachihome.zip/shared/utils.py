import weasyprint
from django.http import HttpResponse
from django.template.loader import render_to_string


def generate_pdf(request, template_path, output_filename_stem, **context):
    html = render_to_string(template_path, context)
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = f'filename={output_filename_stem}.pdf'
    weasyprint.HTML(string=html, base_url=request.build_absolute_uri()).write_pdf(response)
    return response
