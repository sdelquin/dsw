from django import template
from django.contrib.staticfiles import finders

register = template.Library()


@register.filter
def wp_static_path(static_path):
    return f'file://{finders.find(static_path)}'
