from django.db import models


class Product(models.Model):
    name = models.CharField(max_length=256)
    slug = models.SlugField()
    price = models.DecimalField(max_digits=5, decimal_places=2)
    photo = models.ImageField(upload_to='products/%Y/%m/%d/', blank=True, null=True)

    def __str__(self):
        return self.name
