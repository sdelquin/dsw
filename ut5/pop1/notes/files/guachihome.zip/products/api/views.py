from rest_framework import viewsets


class ProductViewSet(viewsets.ReadOnlyModelViewSet):
    pass
