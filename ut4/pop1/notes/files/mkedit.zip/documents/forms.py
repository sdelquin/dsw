from django.forms import ModelForm


class EditDocumentForm(ModelForm):
    pass
