from django.views.decorators.http import require_http_methods


def home(request):
    pass


@require_http_methods(['GET', 'POST'])
def edit_document(request, docref):
    pass


def render_document(request, docref):
    pass
