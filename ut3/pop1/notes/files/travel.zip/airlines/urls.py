app_name = 'airlines'

urlpatterns = []
