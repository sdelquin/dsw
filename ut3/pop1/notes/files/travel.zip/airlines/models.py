from django.db import models


# https://es.wikipedia.org/wiki/Anexo:Aerol%C3%ADneas_de_Espa%C3%B1a
class Airline(models.Model):
    name = models.CharField(max_length=256)
    slug = models.CharField(max_length=256)
    iata = models.CharField(max_length=2, unique=True, verbose_name='IATA')
    web = models.URLField()
    logo = models.ImageField(upload_to='airlines')
