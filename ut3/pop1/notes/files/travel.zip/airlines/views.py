from pathlib import Path

SECTION = Path(__file__).parent.name


def airline_detail(request, airline_slug: str):
    pass
