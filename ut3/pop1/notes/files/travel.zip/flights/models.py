from django.db import models
from django.urls import reverse

from airlines.models import Airline
from airports.models import Airport


class Flight(models.Model):
    code = models.CharField(max_length=64, unique=True)
    departure_from = models.ForeignKey(
        Airport, on_delete=models.CASCADE, related_name='flights_from_here'
    )
    departure_at = models.DateTimeField()
    arrival_to = models.ForeignKey(
        Airport, on_delete=models.CASCADE, related_name='flights_to_here'
    )
    arrival_at = models.DateTimeField()
    airline = models.ForeignKey(Airline, on_delete=models.CASCADE, related_name='flights')

    @property
    def iata_code(self):
        return f'{self.airline.iata}{self.code}'

    def __str__(self):
        return self.iata_code

    def get_absolute_url(self):
        return reverse('flights:flight_detail', args=[self.iata_code.lower()])

    class Meta:
        ordering = ['departure_at']
        indexes = [models.Index(fields=['departure_at'])]
