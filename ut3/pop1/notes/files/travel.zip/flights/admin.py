from django.contrib import admin

from .models import Flight


@admin.register(Flight)
class FlightAdmin(admin.ModelAdmin):
    list_display = ['code', 'airline', 'departure_from', 'arrival_to', 'departure_at', 'arrival_at']
