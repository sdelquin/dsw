app_name = 'flights'

urlpatterns = []
