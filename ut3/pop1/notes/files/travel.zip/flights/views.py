from pathlib import Path

SECTION = Path(__file__).parent.name


def dashboard(request):
    pass


def flight_list(request, arrival_to_city: str = None):
    pass


def flight_detail(request, iata_code: str):
    pass
