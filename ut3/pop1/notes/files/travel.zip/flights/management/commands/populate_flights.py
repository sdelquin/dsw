import random
import string
from datetime import timedelta

from django.core.management.base import BaseCommand
from django.db.utils import IntegrityError

from airlines.models import Airline
from airports.models import Airport
from flights.models import Flight

from ._utils import random_date


class Command(BaseCommand):
    help = 'Populate database with random flights'

    def add_arguments(self, parser):
        parser.add_argument('num_flights', type=int)

    def handle(self, *args, **options):
        num_flights_created = 0
        while num_flights_created < options['num_flights']:
            flight_code = ''.join(random.choices(string.digits, k=4))
            departure_from, arrival_to = random.sample(list(Airport.objects.all()), 2)
            departure_at = random_date()
            arrival_at = departure_at + timedelta(minutes=random.randint(60, 180))
            airline = random.choice(Airline.objects.all())
            try:
                flight = Flight.objects.create(
                    code=flight_code,
                    departure_from=departure_from,
                    departure_at=departure_at,
                    arrival_to=arrival_to,
                    arrival_at=arrival_at,
                    airline=airline,
                )
            except IntegrityError as err:
                self.stdout.write(self.style.ERROR(err))
            else:
                self.stdout.write(self.style.SUCCESS(f'Successfully created flight {flight}'))
                num_flights_created += 1
