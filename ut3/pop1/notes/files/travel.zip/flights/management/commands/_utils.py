from datetime import datetime, timedelta
from random import randrange

from django.utils import timezone


def random_date(start: datetime = None, end: datetime = None) -> datetime:
    """
    This function will return a random datetime between two datetime objects.
    """
    start = timezone.now() if start is None else start
    end = start + timedelta(days=365) if end is None else end

    delta = end - start
    int_delta = (delta.days * 24 * 60 * 60) + delta.seconds
    random_second = randrange(int_delta)
    return start + timedelta(seconds=random_second)
