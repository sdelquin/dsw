from pathlib import Path

SECTION = Path(__file__).parent.name


def airport_detail(request, airport_slug: str):
    pass
