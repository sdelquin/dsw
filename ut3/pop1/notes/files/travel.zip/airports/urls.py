app_name = 'airports'

urlpatterns = []
