from django.db import models
from django.urls import reverse


# https://es.wikipedia.org/wiki/Anexo:Aeropuertos_de_Espa%C3%B1a
class Airport(models.Model):
    name = models.CharField(max_length=256)
    slug = models.CharField(max_length=256)
    iata = models.CharField(max_length=3, unique=True, verbose_name='IATA')
    city = models.CharField(max_length=128)
    photo = models.ImageField(upload_to='airports')

    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse('airports:airport_detail', args=[self.slug])
