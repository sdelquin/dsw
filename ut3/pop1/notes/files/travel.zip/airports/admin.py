from django.contrib import admin

from .models import Airport


@admin.register(Airport)
class AirportAdmin(admin.ModelAdmin):
    list_display = ['name', 'iata', 'city']
    prepopulated_fields = {'slug': ('name',)}
